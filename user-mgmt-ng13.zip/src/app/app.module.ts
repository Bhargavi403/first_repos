import { NgModule } from '@angular/core';
import { BrowserModule, Title } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { MenuComponent } from './shared/components/menu/menu.component';
import { HomeComponent } from './home/components/home.component';
import { ConceptsComponent } from './concepts/components/concepts.component';
import { AboutComponent } from './about/components/about.component';
import { CpbComponent } from './concepts/components/cpb/cpb.component';
import { CebComponent } from './concepts/components/ceb/ceb.component';
import { ColorizerDirective } from './concepts/directives/colorizer.directive';
import { UnlessDirective } from './concepts/directives/unless.directive';
import { UsersModule } from './users/users.module';
import { ProductsModule } from './products/products.module';
import { LoginComponent } from './authentication/components/login/login.component';
import { SignupComponent } from './authentication/components/signup/signup.component';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found/page-not-found.component';
import { EllipsisPipe } from './shared/pipes/ellipsis.pipe';
import { AuthInterceptor } from './shared/interceptors/auth.interceptor';

//Decorator
//Main Switching box
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuComponent,
    HomeComponent,
    ConceptsComponent,
    AboutComponent,
    CpbComponent,
    CebComponent,
    ColorizerDirective,
    UnlessDirective,
    LoginComponent,
    SignupComponent,
    PageNotFoundComponent,
    EllipsisPipe,

  ],
  imports: [
    BrowserModule,
    ProductsModule,
    UsersModule, //Feature Module //Feature module should be on top of AppRoutingModule otherwise the url's in the UserModule is not loaded and Page not found will be visible
    AppRoutingModule,
    FormsModule, //needed for ngModel work
    ReactiveFormsModule, //needed for reactive forms to work
    HttpClientModule

  ],
  providers: [Title,     { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}], //for setting the Title
  bootstrap: [AppComponent]
})
export class AppModule { }
