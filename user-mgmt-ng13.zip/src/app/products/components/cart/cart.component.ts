import { Component, OnInit } from '@angular/core';
import { CartDataService } from 'src/app/shared/services/cart-data.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styles: [
  ]
})
export class CartComponent implements OnInit {
  cartCount: number = 0;
  constructor(private cardDataService: CartDataService) { }

  ngOnInit(): void {
    //Lets subscribe to the cart data
    this.cardDataService.latestCartItems.subscribe((cartItems: any[]) => {
      console.log(cartItems.length);
      this.cartCount = cartItems.length;
    });
  }

}
