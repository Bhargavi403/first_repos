import { Component, OnInit } from '@angular/core';
import { CartDataService } from 'src/app/shared/services/cart-data.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styles: [],
})
export class ProductListComponent implements OnInit {
  constructor(private cartDataService: CartDataService) {}

  ngOnInit(): void {}
  pdtList: any[] = [
    {
      id: 1,
      name: 'Apple',
      category: 'Fruits',
      price: '$2.76',
    },
    {
      id: 2,
      name: 'Cheese',
      category: 'Dairy',
      price: '$6.38',
    },
    {
      id: 3,
      name: 'Orange',
      category: 'Fruits',
      price: '$4.85',
    },
    {
      id: 4,
      name: 'Tomato',
      category: 'Vegetables',
      price: '$5.01',
    },
    {
      id: 5,
      name: 'Table Cloth',
      category: 'Kitchen Essentials',
      price: '$6.13',
    },
  ];

  handleAddToCart(pdt: any): void {
    console.log(pdt);
    this.cartDataService.updateCartItems(pdt); // send data to update in the cart
  }
}
