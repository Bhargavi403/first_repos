import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details',
  template: `
    <p>
      product-details works!
    </p>
  `,
  styles: [
  ]
})
export class ProductDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
