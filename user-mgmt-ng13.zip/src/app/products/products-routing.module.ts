import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './components/product-list/product-list.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { CartComponent } from './components/cart/cart.component';
import { RouterModule, Routes } from '@angular/router';



const routes: Routes = [
  { path: 'products', component: ProductListComponent, data: { title: "Products" } },
  { path: 'products/:id', component: ProductDetailsComponent, data: { title: "Product details" } },
  { path: 'products/cart', component: CartComponent, data: { title: "Product details" } }
]
@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class ProductsRoutingModule { }
