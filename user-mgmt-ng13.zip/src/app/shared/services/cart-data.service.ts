import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable,take } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartDataService {
  //Step 1: lets have default cart items
  //should load the data from REST API
  // but mocking with the static data

  private currentCartItems: any[] = [
    {
      id: 3,
      name: 'orange',
      category: 'Fruits',
      price: '$4.85'
    }
  ];

  //Step2: Lets create Observable , when we write observable that comp can be subscribed by any comp
  // to create obseravble we should have BehaviorObject with the default cart items
  private cartItemsList = new BehaviorSubject(this.currentCartItems);

  //step 3: Lets create Observable for the about BehaviorObject obj so that any comp can subscribe
  latestCartItems: Observable<any[]> = this.cartItemsList.asObservable();

  constructor() { }

  updateCartItems(pdt: any): void {
    console.log("Inside cart data service");
    console.log(pdt);
    this.latestCartItems.pipe(take(1)).subscribe((value: any) => {
      console.log(value); // this will e an array of existing cart items.
      const newCartList = [...value, pdt];
     return this.cartItemsList.next(newCartList);
    })

  }

}
