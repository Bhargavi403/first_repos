import { Component, OnInit } from '@angular/core';
import { bufferToggle, reduce } from 'rxjs';

@Component({
  selector: 'app-footer',
  template: `
  <footer class= "text-center">
  <hr>
  <app-menu>
    <ng-container ngProjectAs="footer-menu">
  <li class="nav-item">
      <a class="nav-link" href="#">Back To Top</a>
    </li>
    </ng-container>
  </app-menu>
  
    <p class="redText">
      Copyright | Ajith
    </p>

    </footer>
  `,
  styles: [
    `.redText{
      color:red;
    }
    `
  ]
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
