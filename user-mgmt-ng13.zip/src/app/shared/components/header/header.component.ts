import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/authentication/services/auth.service';
import { CartDataService } from '../../services/cart-data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  cartCount: number = 0;
  isAuthenticated = false;

  constructor(private cardDataService: CartDataService, private authService: AuthService, private router: Router) { } 

  ngOnInit(): void {
    //Lets subscribe to the cart data
    this.cardDataService.latestCartItems.subscribe((cartItems: any[]) => {
      console.log(cartItems.length,"header component");
      this.cartCount = cartItems.length;
    });
  }
  
  handleLogout(){
    this.authService.logout();
    this.router.navigateByUrl("/");
  }

}
