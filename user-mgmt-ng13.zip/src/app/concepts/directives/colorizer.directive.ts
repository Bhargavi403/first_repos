import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';
//Decorator
@Directive({
  selector: '[appColorizer]',
})
export class ColorizerDirective {
  //1. find the element which is using the appColorizer directive -- using ElementRef class
  //2.Chnage the textcolor
  constructor(private elRef: ElementRef, private renderer: Renderer2) {
    //Dependency injection
    console.log(this.elRef); //this holds the element which is the colorizer directive

    //changed the color using dom element is not recomended
    // this.elRef.nativeElement.style.backgroundColor = 'red';
    // this.elRef.nativeElement.style.color = 'white';
    // this.elRef.nativeElement.style.height = '30px';

    // so gonna use Angular renderer2 class
    this.renderer.setStyle(
      this.elRef.nativeElement,
      'background-color',
      'blue'
    );
    this.renderer.setStyle(this.elRef.nativeElement, 'color', 'white');
    this.renderer.setStyle(this.elRef.nativeElement, 'height', '300px');
  }
  // Event handler for directive

  @HostListener('click', ['$event'])
  handleClick(event: any) {
    console.log('Clicked');
    this.renderer.setStyle(
      this.elRef.nativeElement,
      'background-color',
      'yellow'
    ); // using renderer
    this.renderer.setStyle(event.target, 'color', 'black'); // using event.target
  }
  @HostListener('mouseover', ['$event'])
  handleMouseover(event: any) {
    console.log('Mouseover');
    this.renderer.setStyle(
      this.elRef.nativeElement,
      'background-color',
      'lightgreen'
    );
    this.renderer.setStyle(this.elRef.nativeElement, 'color', 'black');
  }
  @HostListener('mouseleave', ['$event'])
  handleMouseleave(event: any) {
    console.log('Mouseover');
    this.renderer.setStyle(
      this.elRef.nativeElement,
      'background-color',
      'pink'
    );
    this.renderer.setStyle(this.elRef.nativeElement, 'color', 'white');
  }
}
