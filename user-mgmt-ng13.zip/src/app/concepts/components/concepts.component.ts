import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-concepts',
  templateUrl: './concepts.component.html',
  styles: [],
})
export class ConceptsComponent implements OnInit {
  appName = 'UserTest'; //Interpolation related
  teamSize = 12; //Property Binding
  companyName = 'Fujitsu';
  courseName = 'Angular'; //TwoWAy Binding
  switchChoice = '2';
  myAge = 25;
  dataReceivedFromChild = '';
  isAuthenticated = 'TRUE';
  skillList = ['java', 'C#', 'React']; //*ngFor

  //ViewChild

  @ViewChild('someInput') someInput!: ElementRef;
  ngAfterViewInit() {
    this.someInput.nativeElement.value = 'Ajith';
  }

  condition = false; //Custom structural directive
  constructor() {}

  ngOnInit() {}

  //Event Binding
  handleClick(event: any): void {
    event.target.innerText = 'Clicked';
    alert('clicked');
    event.target.disabled = true;
  }

  handleProfileLoaded(event: any) {
    console.log('inside handleprofile');
    this.dataReceivedFromChild = event;
  }
}
