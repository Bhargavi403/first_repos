import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpb',
  template: `<div>
  <p>Age is: {{age}}</p>
</div>
`,
  styleUrls: ['./cpb.component.scss']
})
export class CpbComponent implements OnInit {
  //Step 2: creating custom property in child component
  @Input() age = 20;
  constructor() { }

  ngOnInit(): void {
  }

}
