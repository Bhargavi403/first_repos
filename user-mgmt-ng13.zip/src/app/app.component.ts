import { Component } from '@angular/core';
import { Title } from "@angular/platform-browser";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { filter, map, mergeMap } from "rxjs/operators";
//Step 4: unified by @component ()
@Component({
  selector: 'app-root', //exposed in an element selecotr - to use in index.html
  templateUrl: './app.component.html', //html - template is mandatory for a component  -- should be only one
  styleUrls: ['./app.component.scss'] //scss-- styles are optional -- can be multiple
})
export class AppComponent { //ts
  title = 'user-mgmt-plus-nd13';
  constructor(private titleService: Title, private activatedRoute: ActivatedRoute, private router: Router) {
  }

  ngOnInit() {
    this.router.events
    .pipe(
      filter(event => event instanceof NavigationEnd),
      map(() => {
        let route = this.activatedRoute;
        while (route.firstChild) route = route.firstChild;
        return route;
      }),
      filter((route: any) => route.outlet === "primary"),
      mergeMap((route: any) => route.data),
      map((data: any) => {
        if (data.title) {
          return data.title;
        } else {
          return "Default App Title";
        }
      })
    )
    .subscribe(pathString => this.titleService.setTitle(pathString));
}
  }

