import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UsersComponent } from './components/users.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { UserDetailsComponent } from './components/user-details/user-details.component';

const routes: Routes = [
  { path: 'users', component: UsersComponent, data: { title: "Users" } },
  { path: 'users/add', component: AddUserComponent,data: { title: "Add User" } },
  { path: 'users/:id', component: UserDetailsComponent,data: { title: "User details" } }, //setting URL param , id is the url param
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class UsersRoutingModule { }
