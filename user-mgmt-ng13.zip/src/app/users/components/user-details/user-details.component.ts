import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from '../../models/user.model';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styles: [
  ]
})
export class UserDetailsComponent implements OnInit {
  userData: User = new User; //using the custome datatype User and just Initializing not calling() the Class
  isUpdated: boolean = false;
  duplicateUserData: User = new User;
  currentUserId: String;


  constructor(private userService: UserService, private route: ActivatedRoute)  // connect the service //the ActivateRoute to get the URL Param
  {
    this.currentUserId = this.route.snapshot.params['id'];  // Reading URL Params using Angular
  }

  ngOnInit(): void {
    console.log("Inside OnInit");
    this.userService.getUserById(this.currentUserId) //Reading  URL Params using Angular
      .subscribe((res: User) => { // get the res from the Service  //custom datatype User model
        console.log(res);
        this.userData = res;
      });
  }

  handleUpdateModalOpen(): void {
    this.duplicateUserData = { ...this.userData }; //... object literal  // creating brand new object
  }

  // Async has to be used when we canot use the subscribe in promise
  async handleUpdateForm() {
    console.log(this.duplicateUserData); //formData
    const result: User = await this.userService.updateUserById(this.duplicateUserData); //Async
    console.log(result);
    if (result && result.id) {
      this.isUpdated = true;
      this.userData = result;
    }
  }

  handleDeleteUser() {
    console.log(" Inside delete");
    this.userService.deleteUserById(this.currentUserId)
      .subscribe((res: User) => { // get the res from the Service 
        console.log(res);
        this.userData = res;
        alert("deleted successfully");

      });
  }
}
