import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../models/user.model';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss'],
})
export class AddUserComponent implements OnInit {
  //step 0: have the html for form , already we have add-user.component.html
  //step 1: have the accompanying ts for the form elemetn and the inputs
  addUserForm = new FormGroup({
    //step 2:  have the input equivalent in ts
    name: new FormControl('', Validators.required), //step:5 setup valdators
    phone: new FormControl('', [
      Validators.required,
      Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$'),
    ]),
    email: new FormControl('', [Validators.required, Validators.email]),
    // step 3: refer html for step 3
  });

  isSaved = false; //saved successfully alert
  constructor(private userService: UserService, private router: Router) {
    // connecting the TS with the service class using dependemcy injection
  }

  ngOnInit(): void {}
  handleAddUser(): void {
    console.log('Submitted');
    console.log(this.addUserForm.value); // to get the form data

    // send this data to the user service
    this.userService
      .createUser(this.addUserForm.value)
      .subscribe((res: User) => {
        // recieve response from the service
        console.log(res);
        if (res && res.id) {
          this.isSaved = true; //saved successfully alert
        }
      });
  }

  handleGoBack(): void {
    this.router.navigate(['/users']);
  }
}
