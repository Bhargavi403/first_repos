import { Component, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ignoreElements, Subscription } from 'rxjs';
import { User } from '../models/user.model';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styles: [],
})
export class UsersComponent implements OnInit, OnDestroy {
  userList: User[] = []; // Using the custom datatype User[] model
  title = 'User';

  //Subscribing and Unsubscribing
  userSubscription: Subscription | undefined;

  constructor(private titleService: Title, private userService: UserService) {
    // connect with the service usinf dep inj
  }
  // lifecycle hook
  ngOnInit() {
    console.log('Inside Init');
    this.titleService.setTitle(this.title);

    //about  ngOnInit() ,
    // this called after constructor
    //ideal place to make ajax calls .
    // send the request to service for list all users
    this.userSubscription = this.userService
      .getUser() //storing the subscribed in the the Subscription variable
      .subscribe((res: User[]) => {
        //custome datatype User[] model
        console.log(res); // get the response
        this.userList = res;
      });
  }

  ngOnDestroy(): void {
    console.log('Inside Destroy');
    this.userSubscription?.unsubscribe(); // Unsubscribing the Subsciption when user leaves the page
    if (this.userList && this.userList.length > 0) {
      this.userList.length = 0;
    }
  }
}
