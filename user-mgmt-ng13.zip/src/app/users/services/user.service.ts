import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';


@Injectable({ // InjactableDecorator 
  providedIn: 'root' //configuring Injector // any component can dep inj this service
})
export class UserService {



  constructor(private http: HttpClient, private router: Router) {// dep inj for HTTP client

  }
  createUser(formData: User): Observable<User> { //1. get the data from TS 
    console.log(formData);
    //2. send the data to Rest API
    // 2.1. What's the REST API Endpoint? 'https://jsonplaceholder.typicode.com/users'
    // 2.2. What's the HTTP Method? POST 
    // 2.3. What's the REST API Client Tool? HttpClient

    return this.http.post<User>(`https://jsonplaceholder.typicode.com/users`, formData)
      .pipe(map((res: User) => { // 3. get the res from REST API 
        console.log(res);
        // 4. send the resp back to the comp
        return res;
      }));
  }


  //list all users
  getUser(): Observable<User[]> { //1. got the requst from the the TS  //here using the custom Datatype User[] model // observable type since we are using pipe and map
    console.log("inside service");
    //2.send the request to REST API 
    // 2.1. What's the REST API Endpoint? 'https://jsonplaceholder.typicode.com/users'
    // 2.2. What's the HTTP Method? GET 
    // 2.3. What's the REST API Client Tool? HttpClient
    return this.http.get<User[]>(`https://jsonplaceholder.typicode.com/users`)
      .pipe(map((res: User[]) => { // 3. get the response from the REST API
        console.log(res);
        return res; // 4. send the resp back to the comp
      }));
  }

  //user details by id
  getUserById(userId: String): Observable<User> { //1. got the requst from the the TS 
    console.log(userId);
    //2.send the request to REST API 
    // 2.1. What's the REST API Endpoint? 'https://jsonplaceholder.typicode.com/users'
    // 2.2. What's the HTTP Method? GET 
    // 2.3. What's the REST API Client Tool? HttpClient
    return this.http.get<User>(`https://jsonplaceholder.typicode.com/users/${userId}`) //template literal 
      .pipe(map((res: User) => { // 3. get the response from the REST API
        console.log(res);
        return res; // 4. send the resp back to the comp
      }));
  }


  //update the user
  updateUserById(formData: User): Promise<User> | Promise<any> { //promise type is any since we return sometimes err
    console.log(formData);

    //submitting the data to REST API using the promises and Async await
    return this.http.put<User>(`https://jsonplaceholder.typicode.com/users/${formData.id}`, formData)
      .toPromise() //depracated in rxjs v7 will be removed in  rxjs v8
      .then((res: User|undefined) => {
        console.log(res);
        return res;
      }).catch((err) => {
        console.log(err);
        return err;
      }).finally(() => {
        console.log("it is over!");
      })
  }
  //delete the user -- TODO
  deleteUserById(userId: String): Observable<User> { //1. got the requst from the the TS 
    console.log('Inside deleteUser service');
    //2.send the request to REST API 
    // 2.1. What's the REST API Endpoint? 'https://jsonplaceholder.typicode.com/users'
    // 2.2. What's the HTTP Method? GET 
    // 2.3. What's the REST API Client Tool? HttpClient
    return this.http.delete<User>(`https://jsonplaceholder.typicode.com/users/${userId}`) //template literal 
      .pipe(map((res: User) => { // 3. get the response from the REST API
        console.log(res);
        this.router.navigate(['/users']);
        return res; // 4. send the resp back to the comp

      }));

  }

}